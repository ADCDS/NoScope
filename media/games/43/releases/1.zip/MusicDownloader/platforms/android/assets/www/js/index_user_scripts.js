(function() {
    "use strict";
    /*
      hook up event handlers 
    */
    function register_event_handlers() {


        $(document).on("click", ".uib_w_7", function(evt) {
            activate_subpage("#mainsub");
        });

        
        
        $(document).on("click", ".uib_w_14", function(evt) {
            getResponseFromServer($('#smusic').val(), 1);
            setTitulo('MusicDownloader');
        });
        $(document).on("click", "#sbartista", function(evt) {
            getResponseFromServer($('#sartista').val(), 2);
        });
        $(document).on("click", ".uib_w_6", function(evt) {
            activate_subpage("#artista");
             setTitulo('MusicDownloader');
        });
            $(document).on("click", ".uib_w_5", function(evt)
        {
         activate_subpage("#videos"); 
             setTitulo('MusicDownloader');
        });
        $(document).on("click", "#sbvideo", function(evt)
        {
        getResponseFromServer($('#svideo').val(), 4);
             setTitulo('MusicDownloader');
        });
        $(document).on("click", ".uib_w_4", function(evt)
        {
         activate_subpage("#sobre"); 
             setTitulo('MusicDownloader');
        });
}
    document.addEventListener("app.Ready", register_event_handlers, false);
})();

function getResponseFromServer(text, op) {
    $.get('http://192.168.6.111/MusicDownloader/mobi/android.php?op=' + op + '&text=' + text, function(responseText) {
        xmlDoc = $.parseXML(responseText);
        switch (op) {
            case 1:
            case 3:
                $(".uib_w_15").html("");
                $(xmlDoc).find("musica").each(function() {
                    $(".uib_w_15").append('<li class="widget uib_w_13" data-uib="app_framework/listitem" data-ver="1"><a class="" onclick="downloadMusica(\'' + $(this).attr("url") + '\', \''+$(this).attr("artista")+'\')">' + $(this).attr("nome") + '</a><small>' + $(this).attr("artista") + '</small></li>');
                });
                break;
            case 2:
                $(".uib_w_19").html("");
                $(xmlDoc).find("artista").each(function() {
                    $(".uib_w_19").append('<li id="a-' + $(this).attr("id") + ' "class="widget uib_w_13" data-uib="app_framework/listitem" onclick="loadMusicasFromArtista(\''+$(this).attr("id")+'\', \''+$(this).attr("nome")+'\')"data-ver="1"><a class="" href="#">' + $(this).attr("nome") + '</a></li>');
                });
                break;
            case 4:
            $(".uib_w_25").html("");
                $(xmlDoc).find("musica").each(function() {
                    $(".uib_w_25").append('<li class="widget uib_w_13" data-uib="app_framework/listitem" data-ver="1"><a class="" onclick="downloadMusica(\'' + $(this).attr("url") + '\', \'Videos\'"><img class="yt_thumb" src="http://img.youtube.com/vi/'+ $(this).attr("id") +'/default.jpg"><p>'+$(this).attr("nome") + '</p><p><small>' + $(this).attr("artista") +'</p></a></li>');
                    
                    
               
        }); break;
                                              
                                              }
    });

}

function loadMusicasFromArtista(id_artista, nome) {
    getResponseFromServer(id_artista, 3);
    setTitulo(nome);
    $('.uib_w_7').click();
}

function setTitulo(string){
$('#titulo').html(string);
}

function downloadMusica(url, artist){
    alert(url);
fileTransfer = new FileTransfer();
fileTransfer.download(
    url,
    "file://sdcard/Musicas/"+artist+"/",
    function(entry) {
        alert("download complete: " + entry.fullPath);
    },
    function(error) {
        alert("download error source " + error.source);
        alert("download error target " + error.target);
        alert("upload error code" + error.code);
    });
}