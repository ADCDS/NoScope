/** Automatically generated file. DO NOT MODIFY */
package io.cordova.hellocordova;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}